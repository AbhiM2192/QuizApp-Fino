var finomena = angular.module("finomenaQuiz",['ngRoute','zingchart-angularjs'])

finomena.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "login/login.html",
        controller:"loginController"
    })
    .when("/quiz", {
    	resolve:{
    		"check":function($location,$rootScope){
    				if(!$rootScope.loggedIn){
    					$location.path("/")
    				}
    		}
    	},
        templateUrl : "quiz/quiz.html",
        controller:"quizController"
    })
    .when("/result",{
    	templateUrl : "result/result.html",
    	controller:"resultController"
    })
    .otherwise({
        templateUrl : "login/login.html"
    });

});