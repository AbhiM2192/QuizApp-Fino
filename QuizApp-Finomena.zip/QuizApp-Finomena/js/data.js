finomena.factory("quizData",function(){
	var data = {}
	data.correctAnswers = [1, 3, 2, 3, 0];
	 
	 data.quizQuestions = [{
		type: "text",
		text: "How much amount has been allotted by the Tamil Nadu government for Thaaliku Thangam scheme under marriage assistance programme?",
		possibilities: [{
			answer: "INR 289 crore"
		}, {
			answer: "INR 204 crore"
		}, {
			answer: "INR 223 crore"
		}, {
			answer: "INR 389 crore"
		}],
		selected: null,
		correct: null
	}, {
		type: "text",
		text: "The world’s largest solar power plant has been installed in which state of India?",
		possibilities: [{
			answer: "Andhra Pradesh"
		}, {
			answer: "Madhya Pradesh"
		}, {
			answer: "Maharashtra"
		}, {
			answer: "Tamil Nadu"
		}],
		selected: null,
		correct: null
	}, {
		type: "text",
		text: "he 2016 International Association of Science Parks and Areas of Innovation (IASP) world conference is hosted by which country?",
		possibilities: [{
			answer: "Istanbul"
		}, {
			answer: "New Delhi"
		}, {
			answer: "Moscow"
		}, {
			answer: "Berlin"
		}],
		selected: null,
		correct: null
	}, {
		type: "text",
		text: "Who has been sworn-in as the new Chief Justice of Calcutta High Court?",
		possibilities: [{
			answer: "Jayanta Mitra"
		}, {
			answer: "Manjula Chellur"
		}, {
			answer: "Arun Kumar Mishra"
		}, {
			answer: "Girish Chandra Gupta"
		}],
		selected: null,
		correct: null
	}, {
		type: "text",
		text: "Which Indian film has been selected as the official entry to Oscar Awards 2017 in the foreign language film category?",
		possibilities: [{
			answer: "Visarani"
		}, {
			answer: "Court"
		}, {
			answer: "Tithi"
		}, {
			answer: "Anjali"
		}],
		selected: null,
		correct: null
	}





]




return data;
})
