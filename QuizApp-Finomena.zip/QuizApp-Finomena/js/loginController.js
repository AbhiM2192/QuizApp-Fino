finomena.controller('loginController',function($scope,$location,$rootScope){
	
	
	$scope.quizStart = function(){
		$rootScope.name = $scope.username;
		if($scope.username){
			$rootScope.loggedIn = true
			$location.path('/quiz');
		}
			
		
	}
	
	
})