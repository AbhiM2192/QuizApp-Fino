finomena.factory("markQuiz",["quizData",function(quizData){
	var mark = {}
	mark.numCorrect = 0;
	mark.correctAnswers = [];
	mark.quizMetrics = function(){
		mark.correctAnswers = quizData.correctAnswers;
		for(var i = 0 ; i < quizData.quizQuestions.length; i++){
			if(quizData.quizQuestions[i].selected === quizData.correctAnswers[i]){
				quizData.quizQuestions[i].correct = true;
				mark.numCorrect++;
				
			}else{
				quizData.quizQuestions[i].correct = false;
				
			}
		}
		
	}
	
	return mark;
}])