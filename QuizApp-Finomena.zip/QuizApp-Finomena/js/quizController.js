finomena.controller('quizController',["$scope","$location","$rootScope","quizData","markQuiz",function($scope,$location,$rootScope,quizData,markQuiz){
	
	$scope.quizData = quizData;
	$scope.markQuiz = markQuiz;
	$scope.activeQuestion = 0;
	$scope.error = false;
	$scope.finalise = false;
	
	var numQuestionsAnswered = 0;
	
	$scope.setActiveQuestion = function(index){
		
		if(index === undefined){
			var breakOut = false;
			var quizLength = quizData.quizQuestions.length - 1;
			
			
			while(!breakOut){
				$scope.activeQuestion = $scope.activeQuestion < quizLength?++$scope.activeQuestion:0;
				
				if($scope.activeQuestion === 0){
					$scope.error = true;
				}
				
				if(quizData.quizQuestions[$scope.activeQuestion].selected === null){
					breakOut = true;
				}
			}
		} else{
			$scope.activeQuestion = index;
		}
		
		
	}
	
	$scope.questionAnswered = function(){
		
		var quizLength = quizData.quizQuestions.length;
		
		if(quizData.quizQuestions[$scope.activeQuestion].selected !== null){
			numQuestionsAnswered++;
			
			if(numQuestionsAnswered >= quizLength){
				// Finalise quiz
				for(var i = 0; i < quizLength ; i++){
					if(quizData.quizQuestions[i].selected === null){
						$scope.setActiveQuestion(i);
						return;
					}
				} 
				$scope.error = false;
				$scope.finalise = true;
				return;
			}
		}
		$scope.setActiveQuestion()
		
		
	}
	
	$scope.selectAnswer = function(index){
		quizData.quizQuestions[$scope.activeQuestion].selected = index;
	}
	
	$scope.finaliseAnswers = function(){
		markQuiz.quizMetrics();
		$scope.finalise = false;
		numQuestionsAnswered = 0;
		$scope.activeQuestion = 0;
		
		$location.path("/result");
		
	}
}])