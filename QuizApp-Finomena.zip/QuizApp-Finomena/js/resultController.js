finomena.controller('resultController',["$scope","$location","$rootScope","quizData","markQuiz",function($scope,$location,$rootScope,quizData,markQuiz){
	$scope.quizData = quizData;
	$scope.markQuiz = markQuiz;
	$scope.activeQuestion = 0;
	$scope.showGraph = false;
	
	$scope.getAnswerClass = function(index){
		if(index === markQuiz.correctAnswers[$scope.activeQuestion]){
			return "bg-success";
		}else if(index === quizData.quizQuestions[$scope.activeQuestion].selected){
			return "bg-danger";
		}
	}
	
	$scope.setActiveQuestion = function(index){
		$scope.activeQuestion = index;
	}
	
	$scope.calculatePerc = function(){
		return markQuiz.numCorrect / quizData.quizQuestions.length * 100;
	}
	
	$scope.reset = function(){
		$location.path("/");
		markQuiz.numCorrect = 0;
		
		for(var i = 0; i < quizData.quizQuestions.length; i++ ){
			var data = quizData.quizQuestions[i];
			
			data.selected = null;
			data.correct = null;
		}
	}
	
	$scope.myJson = {
		      type : "bar",
		      title:{
		        backgroundColor : "transparent",
		        fontColor :"black",
		        text : "Marks Scored"
		      },
		      backgroundColor : "white",
		      series : [
		        {
		          values : [],
		          backgroundColor : "#4DC0CF"
		        }
		      ]
		    };
	
	
	$scope.seeGraph = function(){
		$scope.showGraph = true;
		
		var val = markQuiz.numCorrect / quizData.quizQuestions.length * 100;
		$scope.myJson.series[0].values.push(val);
	}
	
	
}])